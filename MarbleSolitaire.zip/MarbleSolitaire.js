document.addEventListener("DOMContentLoaded", function () {
    const boardElement = document.getElementById('board');
    const scoreElement = document.getElementById('score');
    const messageElement = document.getElementById('message');
    const board = [[0, 0, 1, 1, 1, 0, 0],
                [0, 0, 1, 1, 1, 0, 0],
                [1, 1, 1, 1, 1, 1, 1],
                [1, 1, 1, 0, 1, 1, 1],
                [1, 1, 1, 1, 1, 1, 1],
                [0, 0, 1, 1, 1, 0, 0],
                [0, 0, 1, 1, 1, 0, 0]];
    let score = 0;
    let gameover = false;
    function renderBoard() {
        boardElement.innerHTML = '';
        for (let i = 0; i < 7; i++) {
            for (let j = 0; j < 7; j++) {
                const cell = document.createElement('div');
                cell.className = `cell ${board[i][j] === 0 ? 'empty' : ''}`;
                cell.dataset.row = i;
                cell.dataset.col = j;
                cell.textContent = '';
                cell.onclick = () => handleCellClick(i, j);
                boardElement.appendChild(cell);
            }
        }
    }

    function isValidMove(row1, col1, row2, col2) {
        return (
            Math.abs(row1 - row2) === 2 && col1 === col2 ||
            Math.abs(col1 - col2) === 2 && row1 === row2
        );
    }

    function handleCellClick(row, col) {
        if (gameover) return;

        if (board[row][col] === 0) {
            const selectedCell = boardElement.querySelector('.highlighted');
            if (selectedCell) {
                const [selectedRow, selectedCol] = [parseInt(selectedCell.dataset.row), parseInt(selectedCell.dataset.col)];
                if (isValidMove(selectedRow, selectedCol, row, col)) {
                    const newRow = (selectedRow + row) / 2;
                    const newCol = (selectedCol + col) / 2;

                    if (board[newRow][newCol] === 1) {
                        board[selectedRow][selectedCol] = 0;
                        board[newRow][newCol] = 0;
                        board[row][col] = 1;
                        score += 1;
                    } else {
                        messageElement.textContent = 'Invalid move!';
                    }
                    renderBoard();
                    scoreElement.textContent = score;
                    messageElement.textContent = '';
                }
            }
        } else {
            const selectedCell = boardElement.querySelector('.highlighted');
            if (selectedCell) {
                selectedCell.classList.remove('highlighted');
            }
            board[row][col] = 1;
            renderBoard();
            document.querySelector(`[data-row="${row}"][data-col="${col}"]`).classList.add('highlighted');
        }
        checkGameover();
    }

    function checkGameover() {
        let possibleMoves = 0;
        for (let i = 0; i < 7; i++) {
            for (let j = 0; j < 7; j++) {
                if (board[i][j] === 1) {
                    if (i >= 2 && board[i - 1][j] === 1 && board[i - 2][j] === 0) {
                        possibleMoves++;
                    }
                    if (i <= 4 && board[i + 1][j] === 1 && board[i + 2][j] === 0) {
                        possibleMoves++;
                    }
                    if (j >= 2 && board[i][j - 1] === 1 && board[i][j - 2] === 0) {
                        possibleMoves++;
                    }
                    if (j <= 4 && board[i][j + 1] === 1 && board[i][j + 2] === 0) {
                        possibleMoves++;
                    }
                }
            }
        }
        if (possibleMoves === 0) {
            gameover = true;
            messageElement.textContent = `Game over! Your score is ${score}.`;
        }
    }
    renderBoard();
});